create view info
            ("Номер заказа", "Категория", "Наименование", "Цена", "Количество", "Работа", "Стоимость работы",
             "Итого") as
SELECT toorder.orderid                                     AS "Номер заказа",
       parts.category                                      AS "Категория",
       parts.title                                         AS "Наименование",
       parts.price                                         AS "Цена",
       toorder.numofparts                                  AS "Количество",
       operations.description                              AS "Работа",
       operations.price                                    AS "Стоимость работы",
       parts.price * toorder.numofparts + operations.price AS "Итого"
FROM operations
         JOIN (parts
    JOIN toorder ON parts.partid = toorder.partid) ON operations.operationid = toorder.operationid
ORDER BY toorder.orderid;

alter table info
    owner to postgres;

